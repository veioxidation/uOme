from User import User
from SingleEntry import SingleEntry
from EntryRegistry import EntryRegistry
from Solver import SolveEntry


class Group:
    def __init__(self, owner):
        self.users = {owner.ID: owner}
        self.registry = EntryRegistry()

    def CreateUser(self, username):
        _id = len(self.users)
        while _id in self.users:
            _id += 1
        self.users[_id] = User(username, _id)

    def DeleteUser(self, user_id):
        self.users.pop(user_id)

    def GetUserByID(self, id_num):
        return self.users[id_num]

    def AddEntry(self, name, amount, payer, paid_for):
        new_entry = SingleEntry(name, amount, payer, paid_for)
        self.registry.entries.append(new_entry)
        print("Entry: {} , amount: {} $ , paid by: {} for {}. Timestamp: {}".format(name, amount, payer, paid_for,
                                                                                    new_entry.time))
        SolveEntry(self, new_entry)

    def GroupInfo(self):
        for user in self.users.values():
            print('-' * 20, user.ID, '-' * 20)
            user.UserInfo()


    def SumMoney(self):
        return sum([user.RB for user in self.users.values()])

    def SolveBalance(self):
        _tolerance = 0.01
        balance_list = {user.ID: user.Balance() for user in self.users.values() if abs(user.Balance()) >= _tolerance}

        while 1:
            # find users with lowest and highest balances
            lowest_bal = 0
            highest_bal = 0
            lowest_id = None
            highest_id = None
            for i in balance_list:
                if lowest_bal > balance_list[i] or lowest_id == None:
                    lowest_bal = balance_list[i]
                    lowest_id = i
                if highest_bal < balance_list[i] or highest_id == None:
                    highest_bal = balance_list[i]
                    highest_id = i
            # transfer minimum of absolute of balances
            transfer_amount = min(abs(lowest_bal), highest_bal)
            balance_list[highest_id] -= transfer_amount
            balance_list[lowest_id] += transfer_amount
            print("{0:<10.2f} should be transferred from user {1} to user {2}.".format(transfer_amount,
                                                                                       self.users[lowest_id].name,
                                                                                       self.users[highest_id].name))

            # remove user from dictionary if balance is equal to zero
            for user_id in [highest_id, lowest_id]:
                if abs(balance_list[user_id]) < _tolerance:
                    balance_list.pop(user_id)

            if len(balance_list) <= 1:
                break

        print("Transferring finished.")
