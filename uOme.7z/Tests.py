from Group import Group
from User import User

new_group = Group(User("Przemek"))

for name in ['Ania', 'Marian', "marian", 'Kamila']:
    new_group.CreateUser(name)

new_group.AddEntry("Jedzenie", 10000, 0, [1, 2, 3])
new_group.AddEntry("hehehe", 10000, 2, [1, 2, 3, 4])
new_group.AddEntry("hehehehe", 1000, 2, [1, 2, 4])
new_group.AddEntry("eeeeeeeee", 10000, 3, [2, 1])
new_group.AddEntry("makarenba", 10000, 1, [1, 2, 1])


new_group.GroupInfo()

print(new_group.SumMoney(),"\n")

new_group.SolveBalance()