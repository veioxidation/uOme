import os
import configparser


class EntryRegistry:
    def __init__(self):
        self.file = ""
        self.config = configparser.ConfigParser()
        self.entries = []
