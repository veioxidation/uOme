class User:
    def __init__(self, name, id_number=0):
        self.ID = id_number
        self.name = name
        self.RB = 0
        self.TB = 0

    def AddToRB(self, amount):
        self.RB += amount

    def AddToTB(self, amount):
        self.TB += amount

    def UserInfo(self):
        user_info = "Name: {}\nReal balance: {}\nTheoritical balance:{}\nBALANCE: {}".format(self.name, self.RB, self.TB, self.Balance())
        print(user_info)

    def Balance(self):
        return round(self.RB - self.TB,2)
